using FishNet.Object;
using UnityEngine;
using System;

public class AntiCheatManager : NetworkBehaviour
{
    public static AntiCheatManager Instance;
    
    void Awake() { Instance = this; }
    
    [Server]
    public static bool ValidateMovement(EclipsePlayer player, Vector3 oldPos, Vector3 newPos, float deltaTime)
    {
        float distance = Vector3.Distance(oldPos, newPos);
        float maxSpeed = player.moveSpeed * 1.2f; // %20 tolerans
        float maxDistance = maxSpeed * deltaTime;
        
        if(distance > maxDistance + 5f) // Speed hack
        {
            BanPlayer(player, "Speed Hack");
            return false;
        }
        return true;
    }
    
    [Server]
    public static bool ValidateDamage(EclipsePlayer attacker, int damage)
    {
        int maxPossibleDmg = attacker.totalAttack * 3; // Max crit x3
        if(damage > maxPossibleDmg)
        {
            BanPlayer(attacker, "Damage Hack");
            return false;
        }
        return true;
    }
    
    [Server]
    public static bool ValidateGold(EclipsePlayer player, int amount)
    {
        if(amount > 100000000) // 100M tek seferde
        {
            BanPlayer(player, "Gold Hack");
            return false;
        }
        return true;
    }
    
    [Server]
    static void BanPlayer(EclipsePlayer player, string reason)
    {
        ChatManager.ServerMessage($"[ANTI-CHEAT] {player.playerName} banlandı! Sebep: {reason}");
        PlayerPrefs.SetInt($"Ban_{player.playerId}", 1);
        player.GetComponent<NetworkObject>().Despawn();
    }
    
    [Server]
    public static bool IsBanned(int playerId)
    {
        return PlayerPrefs.GetInt($"Ban_{playerId}", 0) == 1;
    }
}