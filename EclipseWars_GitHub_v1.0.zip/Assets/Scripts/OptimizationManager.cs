using UnityEngine;
using System.Collections.Generic;

public class OptimizationManager : MonoBehaviour
{
    public static int maxPlayersPerZone = 50;
    public static int lodDistance = 50;
    
    void Start()
    {
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
        QualitySettings.lodBias = 0.5f;
        QualitySettings.shadowDistance = 30f;
        QualitySettings.antiAliasing = 0;
        
        // Mobil optimizasyon
        #if UNITY_ANDROID
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        QualitySettings.SetQualityLevel(2); // Medium
        #endif
    }
    
    // Object Pooling
    public static Dictionary<string, Queue<GameObject>> pool = new();
    
    public static GameObject SpawnPooled(string prefabName, Vector3 pos)
    {
        if(!pool.ContainsKey(prefabName)) pool[prefabName] = new Queue<GameObject>();
        GameObject obj = pool[prefabName].Count > 0 ? 
            pool[prefabName].Dequeue() : 
            Instantiate(Resources.Load<GameObject>($"Prefabs/{prefabName}"));
        obj.transform.position = pos;
        obj.SetActive(true);
        return obj;
    }
    
    public static void DespawnPooled(GameObject obj, string prefabName)
    {
        obj.SetActive(false);
        pool[prefabName].Enqueue(obj);
    }
}