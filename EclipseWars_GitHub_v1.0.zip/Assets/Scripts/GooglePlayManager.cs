using UnityEngine;
#if UNITY_ANDROID
using GooglePlayGames;
using GooglePlayGames.BasicApi;
#endif

public class GooglePlayManager : MonoBehaviour
{
    void Start()
    {
        #if UNITY_ANDROID
        PlayGamesPlatform.Activate();
        Login();
        #endif
    }
    
    public void Login()
    {
        #if UNITY_ANDROID
        Social.localUser.Authenticate((success) => {
            if(success) Debug.Log("Google Play giriş başarılı");
        });
        #endif
    }
    
    public static void UnlockAchievement(string id)
    {
        #if UNITY_ANDROID
        Social.ReportProgress(id, 100.0f, null);
        #endif
    }
    
    public static void PostLeaderboard(int score, string boardId)
    {
        #if UNITY_ANDROID
        Social.ReportScore(score, boardId, null);
        #endif
    }
    
    public static void ShowAchievements()
    {
        #if UNITY_ANDROID
        Social.ShowAchievementsUI();
        #endif
    }
    
    public static void ShowLeaderboard()
    {
        #if UNITY_ANDROID
        Social.ShowLeaderboardUI();
        #endif
    }
}